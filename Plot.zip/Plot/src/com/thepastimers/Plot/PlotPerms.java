package com.thepastimers.Plot;

import com.thepastimers.Database.Database;
import com.thepastimers.Database.Table;

import java.security.acl.Owner;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: derp
 * Date: 10/4/12
 * Time: 7:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class PlotPerms extends Table {
    public static String table = "plot_perms";
    
    int id;
    
    public PlotPerms() {
        id = -1;
    }
    
    int plot;
    String player;
    int perm;

    public static int OWNER = 30;
    public static int COOWNER = 25;
    public static int RESIDENT = 20;
    public static int WORKER = 10;
    public static int NONE = 0;

    public int getPlot() {
        return plot;
    }

    public void setPlot(int plot) {
        this.plot = plot;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPlayer() {
        return player;
    }

    public void setPlayer(String player) {
        this.player = player;
    }

    public int getPerm() {
        return perm;
    }

    public void setPerm(int perm) {
        this.perm = perm;
    }

    public static List<PlotPerms> parseResult(ResultSet result) throws SQLException {
        List<PlotPerms> ret = new ArrayList<PlotPerms>();

        if (result == null) {
            return ret;
        }

        while (result.next()) {
            PlotPerms p = new PlotPerms();

            p.setId(result.getInt("id"));
            p.setPlot(result.getInt("plot"));
            p.setPlayer(result.getString("player"));
            p.setPerm(result.getInt("perm"));
            ret.add(p);
        }

        return ret;
    }

    public boolean delete(Database d) {
        if (id == -1) {
            return true;
        }
        if (d == null) {
            return false;
        }
        return d.query("DELETE FROM " + table + " WHERE ID = " + id);
    }

    public boolean save(Database d) {
        if (d == null) {
            return false;
        }
        if (id == -1) {
            String columns = "(plot,player,perm)";
            String values = "(" + plot + ",'" + d.makeSafe(player) + "'," + perm + ")";
            return d.query("INSERT INTO " + table + columns + " VALUES" + values);
        } else {
            StringBuilder query = new StringBuilder();
            query.append("UPDATE " + table + " SET ");

            query.append("plot = " + plot + ", ");
            query.append("player = '" + d.makeSafe(player) + "', ");
            query.append("perm = " + perm + " ");

            query.append("WHERE id = " + id);
            return d.query(query.toString());
        }
    }
}
