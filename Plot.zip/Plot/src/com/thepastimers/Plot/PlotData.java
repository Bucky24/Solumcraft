package com.thepastimers.Plot;

import com.thepastimers.Database.Database;
import com.thepastimers.Database.Table;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: derp
 * Date: 10/4/12
 * Time: 7:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class PlotData extends Table {
    public static String table = "plot";
    
    int id;
    
    public PlotData() {
        id = -1;
        pvp = false;
        pve = false;
    }
    
    String name;
    String owner;
    int x1;
    int z1;
    int x2;
    int z2;
    String world;
    boolean subPlot;
    int parent;
    
    boolean pvp;
    boolean pve;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public int getX1() {
        return x1;
    }

    public void setX1(int x1) {
        this.x1 = x1;
    }

    public int getZ1() {
        return z1;
    }

    public void setZ1(int z1) {
        this.z1 = z1;
    }

    public int getX2() {
        return x2;
    }

    public void setX2(int x2) {
        this.x2 = x2;
    }

    public int getZ2() {
        return z2;
    }

    public void setZ2(int z2) {
        this.z2 = z2;
    }

    public boolean isSubPlot() {
        return subPlot;
    }

    public void setSubPlot(boolean subPlot) {
        this.subPlot = subPlot;
    }

    public int getParent() {
        return parent;
    }

    public void setParent(int parent) {
        this.parent = parent;
    }

    public boolean isPvp() {
        return pvp;
    }

    public void setPvp(boolean pvp) {
        this.pvp = pvp;
    }

    public boolean isPve() {
        return pve;
    }

    public void setPve(boolean pve) {
        this.pve = pve;
    }

    public String getWorld() {
        return world;
    }

    public void setWorld(String world) {
        this.world = world;
    }

    public static List<PlotData> parseResult(ResultSet result) throws SQLException {
        List<PlotData> ret = new ArrayList<PlotData>();

        if (result == null) {
            return ret;
        }

        while (result.next()) {
            PlotData p = new PlotData();

            p.setId(result.getInt("id"));
            p.setName(result.getString("name"));
            p.setOwner(result.getString("owner"));
            p.setX1(result.getInt("x1"));
            p.setZ1(result.getInt("z1"));
            p.setX2(result.getInt("x2"));
            p.setZ2(result.getInt("z2"));
            p.setSubPlot(result.getBoolean("subPlot"));
            p.setParent(result.getInt("parent"));
            p.setPvp(result.getBoolean("pvp"));
            p.setPve(result.getBoolean("pve"));
            p.setWorld(result.getString("world"));

            ret.add(p);
        }

        return ret;
    }

    public boolean delete(Database d) {
        if (id == -1) {
            return true;
        }
        if (d == null) {
            return false;
        }
        return d.query("DELETE FROM " + table + " WHERE ID = " + id);
    }

    public boolean save(Database d) {
        if (d == null) {
            return false;
        }
        if (id == -1) {
            String columns = "(name,owner,x1,z1,x2,z2,subPlot,parent,pvp,pve,world)";
            String values = "('" + d.makeSafe(name) + "','" + d.makeSafe(owner) + "'," + x1 + "," + z1
                    +  "," + x2 + "," + z2 + "," + subPlot + "," + parent + "," + pvp + "," + pve + ",'"
                    + d.makeSafe(world) + "')";
            return d.query("INSERT INTO " + table + columns + " VALUES" + values);
        } else {
            StringBuilder query = new StringBuilder();
            query.append("UPDATE " + table + " SET ");

            query.append("name = '" + d.makeSafe(name) + "'" + ", ");
            query.append("owner = '" + d.makeSafe(owner) + "', ");
            query.append("x1 = " + x1 + ", ");
            query.append("z1 = " + z1 + ", ");
            query.append("x2 = " + x2 + ", ");
            query.append("z2 = " + z2 + ", ");
            query.append("subPlot = " + subPlot + ", ");
            query.append("parent = " + parent + ", ");
            query.append("pvp = " + pvp + ", ");
            query.append("pve = " + pve + ", ");
            query.append("world = '" + d.makeSafe(world) + "' ");

            query.append("WHERE id = " + id);
            return d.query(query.toString());
        }
    }
}
